<snippet>
  <content>
#Player Movement
These program is a sample of movement in my future Zork Game.
## Credits
By Julià Mauri Costa

  <tabTrigger>readme</tabTrigger>
</snippet>
